﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ПР1_проект
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            ImplicitCasting();
        }

        // Пункт 1. Неявное преобразование.
        // Неявное преобразование простых и ссылочных типов,
        public void ImplicitCasting()
        {
            int Value = 19;
            long result = Value;
            /*Из типа  | В тип
            |Sbyte     |short, int, long, float, double, decimal
            |Byte      |short, ushort, int, uint, long, ulong, float, double, decimal
            |Short     |int, long, float, double, decimal
            |Ushort    |int, uint, long, ulong, float, double, decimal
            |Int       |long, float, double, decimal
            |Uint      |long, ulong, float, double, decimal
            |Long      |float, double, decimal
            |Ulong     |float, double, decimal
            |Float     |double
            |Char      |ushort, int, uint, long, ulong, float, double, decimal*/

            // Создаем объект класса Employee
            Employee empl = new Employee();

            // Присваиваем ссылку на объект Employee переменной типа Person
            Person person = empl; // Неявное преобразование ссылочного типа

            // Выводим результат в MessageBox
            MessageBox.Show(result.ToString());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ExplicitCasting();
        }

        // Пункт 2. Явное преобразование.

        // Явное преобразование простых и ссылочных типов, 

        public void ExplicitCasting()
        {
            /*Таблица явных преобразований
            |Исходный тип |Целевой тип
            |sbyte        |byte, ushort, uint, ulong или char
            |byte         |sbyte или char
            |short        |sbyte, byte, ushort, uint, ulong или char
            |ushort       |sbyte, byte, short или char
            |int          |sbyte, byte, short, ushort, uint, ulong или char
            |uint         |sbyte, byte, short, ushort, int или char
            */
            // Создаем переменную типа long и присваиваем ей значение
            long num1 = 1231232133333333;

            // Производим явное преобразование типа long в тип int и присваиваем результат переменной num2
            int num2 = (int)(num1 + 1000);

            // Создаем объект класса Vec2 и инициализируем его значениями
            Vec2 vector = new Vec2(1.0F, 1.0F);

            // Производим неявное преобразование объекта класса Vec2 в массив типа int
            var raw_vector = (int[])vector;

            // Выводим значения массива в MessageBox
            MessageBox.Show(raw_vector[0].ToString() + ", " + raw_vector[1].ToString());
        }


        private void button3_Click(object sender, EventArgs e)
        {
            CatchCastingException();
        }

        // Пункт 3. Вызвать и обработать исключение преобразования типов.

        public void CatchCastingException()
        {
            // Создаем переменную типа bool и присваиваем ей значение true
            bool flag = true;

            // Пробуем выполнить преобразование типа bool в тип Char
            try
            {
                // Присваиваем переменной conv ссылку на объект типа bool, реализующий интерфейс IConvertible
                IConvertible conv = flag;

                // Производим преобразование типа bool в тип Char
                Char ch = conv.ToChar(null);
            }
            catch (InvalidCastException e)
            {
                // Если произошло исключение InvalidCastException, выводим сообщение об ошибке в MessageBox
                MessageBox.Show($"Поймано исключение пребразования типов {e}");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SafeCasting();
        }

        // Пункт 4. Безопасное приведение ссылочных типов с помощью операторов as и is.

        public void SafeCasting()
        {
            // Создаем объект класса Employee
            Employee employee = new Employee();

            // Проверяем, является ли объект employee экземпляром класса Person
            if (employee is Person)
            {
                // Если да, то производим явное преобразование объекта employee в тип Person с помощью оператора as
                Person person = employee as Person;

                // Выводим сообщение об успешном преобразовании в MessageBox
                MessageBox.Show("Успешно преобразован Person в Employee");
            }
            else
            {
                // Если нет, то выводим сообщение об ошибке в MessageBox
                MessageBox.Show("нельзя");
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            UserImplicitExplicit();
        }

        // Пункт 5. Пользовательское преобразование типов Implicit, Explicit;

        public void UserImplicitExplicit()
        {
            // Создаем объект класса Vec2 и инициализируем его значениями
            Vec2 vec = new Vec2(1.0F, 1.0F);

            // Производим неявное пользовательское преобразование объекта vec в массив типа float
            float[] float_vector = vec;

            // Выводим сообщение об успешном выполнении преобразований в MessageBox
            MessageBox.Show("Успешно выполнены явное и неявное пользовательские преобразования");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            ConvertTask();
        }

        /// Пункт 6. 6)	Преобразование с помощью класса Convert и преобразование 
        /// строки в число с помощью методов Parse,
        /// TryParse класса System.Int32.

        public void ConvertTask()
        {
            // Создаем переменную типа double и присваиваем ей значение
            double dNumber = 27.17;

            // Производим явное преобразование типа double в тип bool с помощью метода Convert.ToBoolean
            bool bNumber = System.Convert.ToBoolean(dNumber);

            // Проверяем, удалось ли выполнить преобразование, и выводим сообщение об успешном выполнении в MessageBox
            if (bNumber)
            {
                MessageBox.Show("Успешно конвертирован double во float при помощи Convert");
            }

            // Создаем строку, содержащую число в виде символов
            string string_number = "100";

            // Производим явное преобразование строки в число типа int с помощью метода Int32.Parse
            int number = System.Int32.Parse(string_number);

            // Проверяем, удалось ли выполнить преобразование, и выводим сообщение об успешном выполнении в MessageBox
            if (number == 100)
            {
                MessageBox.Show("Успешно конвертирована строка 100 в число 100");
            }

            // Создаем объект класса Random и генерируем случайную строку, содержащую число в виде слова или цифр
            Random random = new Random();
            string possibly_number = (random.Next(0, 2) == 1) ? "сто" : "100";

            // Производим неявное преобразование строки в число типа int с помощью метода int.TryParse
            bool success = int.TryParse(possibly_number, out number);

            // Проверяем, удалось ли выполнить преобразование, и выводим сообщение об успешном выполнении или ошибке в MessageBox
            if (success)
            {
                MessageBox.Show($"Конвертировано '{possibly_number}' в {number}.");
            }
            else
            {
                MessageBox.Show($"Не вышло преобразовать {possibly_number} в int");
            }

        }


        // Пункт 7. Написать программу, позволяющую ввод в текстовое поле TextBox
        // только символов, задающих правильный формат вещественного числа со знаком.

        // <param name="sender"></param>
        // <param name="e"></param>
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Получаем символ, нажатый пользователем
            char pressed = e.KeyChar;

            // Проверяем, является ли нажатый символ цифрой или BackSpace
            if (!Char.IsDigit(pressed) && !((int)pressed == 8))
            {
                // Если нажатый символ не является цифрой или BackSpace, то проверяем, является ли он точкой
                if (!(pressed == '.'))
                {
                    // Если нажатый символ не является точкой, то отменяем его обработку
                    e.Handled = true;
                }

                // Проверяем, содержит ли текстовое поле уже точку
                if (textBox1.Text.Contains('.')) e.Handled = true;
            }
        }

        /// Возвращает динамический тип с каким-то значением типа type
  
        /// <param name="type"></param>
        /// <returns></returns>
        private dynamic SetType(string type)
        {
            //char, string, byte, int, float, double, decimal, bool, object
            switch (type)
            {
                case "char": return 'A';
                case "string": return "Какая-то строка";
                case "byte": return (byte)101;
                case "int": return 911;
                case "float": return 3.14F;
                case "double": return 3.141592653589793D;
                case "decimal": return 3.141592653589793M;
                case "bool": return true;
                case "object": return new object();
                default: return null;
            }
        }
        /// <summary>
        /// Проверяет явное пребразование типа в тип.
        /// </summary>
        /// <param name="value1"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentException"></exception>
        private bool TestExplicitIntoType(dynamic value1, string type) {
            try
            {
                switch (type)
                {
                    case "char":
                        var var1 = (char)value1;
                        break;
                    case "string":
                        var var2 = (string)value1;
                        break;
                    case "byte":
                        var var3 = (byte)value1;
                        break;
                    case "int":
                        var var4 = (int)value1;
                        break;
                    case "float":
                        var var5 = (float)value1;
                        break;
                    case "double":
                        var var6 = (double)value1;
                        break;
                    case "decimal":
                        var var7 = (decimal)value1;
                        break;
                    case "bool":
                        var var8 = (bool)value1;
                        break;
                    case "object":
                        var var9 = (object)value1;
                        break;
                    default: throw new ArgumentException();
                }
            }
            catch (Microsoft.CSharp.RuntimeBinder.RuntimeBinderException) {
                return false;
            }
            return true;
        }
        /// <summary>
        /// Проверяет неявное преобразование типа в тип.
        /// </summary>
        /// <param name="value1"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentException"></exception>
        private bool TestImplicitIntoType(dynamic value1, string type)
        {
            try
            {
                switch (type)
                {
                    case "char":
                        char var1 = value1;
                        break;
                    case "string":
                        string var2 = value1;
                        break;
                    case "byte":
                        byte var3 = value1;
                        break;
                    case "int":
                        int var4 = value1;
                        break;
                    case "float":
                        float var5 = value1;
                        break;
                    case "double":
                        double var6 = value1;
                        break;
                    case "bool":
                        bool var7 = value1;
                        break;
                    case "object":
                        object var8 = value1;
                        break;
                    default: throw new ArgumentException();
                }
            }
            catch (Microsoft.CSharp.RuntimeBinder.RuntimeBinderException)
            {
                return false;
            }
            return true;
        }
        /// <summary>
        /// Кнопка, при нажатии которой происходит обработка преобразования из одного типа в другой.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button7_Click(object sender, EventArgs e)
        {
            // Проверяем, выбраны ли типы для преобразования
            if (comboBox1.SelectedItem is null || comboBox2.SelectedItem is null)
            {
                MessageBox.Show("Выберите типы для преобразования");
                return;
            }

            // Проверяем, выбрано ли явное или неявное преобразование
            if (comboBox3.SelectedItem is null)
            {
                MessageBox.Show("Выберите явное или неявное преобразование");
                return;
            }

            // Получаем значение первого типа и преобразуем его в соответствующий тип данных
            dynamic value1 = SetType(comboBox1.SelectedItem.ToString());

            // Получаем значение второго типа
            string type = comboBox2.SelectedItem.ToString();

            // Объявляем переменные для хранения результата преобразования и способа преобразования
            bool convertion_succeed;
            string conversion_way;

            // Проверяем, какой тип преобразования был выбран
            if (comboBox3.SelectedItem.ToString() == "Явное преобразование")
            {
                // Если выбрано явное преобразование, то устанавливаем соответствующее значение переменной conversion_way
                conversion_way = "явно";

                // Вызываем метод TestExplicitIntoType для проверки возможности явного преобразования
                convertion_succeed = TestExplicitIntoType(value1, type);
            }
            else
            {
                // Если выбрано неявное преобразование, то устанавливаем соответствующее значение переменной conversion_way
                conversion_way = "неявно";

                // Вызываем метод TestImplicitIntoType для проверки возможности неявного преобразования
                convertion_succeed = TestImplicitIntoType(value1, type);
            }

            // Проверяем, удалось ли выполнить преобразование, и выводим сообщение об успешном выполнении или ошибке в MessageBox
            if (convertion_succeed)
            {
                var message = $"Успешно {conversion_way} конвертировано {value1.GetType()} в {type}";
                MessageBox.Show(message);
            }
            else
            {
                var message = $"Не получилось {conversion_way} конвертировать {value1.GetType()} в {type}";
                MessageBox.Show(message);
            }
        }
    }
}
