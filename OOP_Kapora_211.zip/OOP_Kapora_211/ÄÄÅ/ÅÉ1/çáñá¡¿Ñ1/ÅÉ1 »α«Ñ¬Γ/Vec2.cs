﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ПР1_проект
{
    /// <summary>
    /// Класс, представляющий двумерный вектор
    /// </summary>
    internal class Vec2
    {
        protected float x, y; // Объявляем поля класса

        /// <summary>
        /// Конструктор класса Vec2
        /// </summary>
        /// <param name="x">Координата по оси X</param>
        /// <param name="y">Координата по оси Y</param>
        public Vec2(float x, float y)
        {
            this.x = x; // Присваиваем полю x значение параметра x
            this.y = y; // Присваиваем полю y значение параметра y
        }

        /// <summary>
        /// Явное преобразование вектора в массив целых чисел
        /// </summary>
        /// <param name="param">Вектор, который нужно преобразовать</param>
        /// <returns>Массив целых чисел, содержащий координаты вектора</returns>
        public static explicit operator int[](Vec2 param)
        {
            int[] output = { (int)param.x, (int)param.y }; // Создаем массив целых чисел и присваиваем ему значения полей x и y, приведенные к типу int
            return output; // Возвращаем созданный массив
        }

        /// <summary>
        /// Неявное преобразование вектора в массив чисел с плавающей точкой
        /// </summary>
        /// <param name="param">Вектор, который нужно преобразовать</param>
        /// <returns>Массив чисел с плавающей точкой, содержащий координаты вектора</returns>
        public static implicit operator float[](Vec2 param)
        {
            float[] output = { param.x, param.y }; // Создаем массив чисел с плавающей точкой и присваиваем ему значения полей x и y
            return output; // Возвращаем созданный массив
        }
    }
}
