﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR3
{
    internal class Task2
    {
        /// <summary>
        /// Отображает матрицу в DataGridView в указанной панели.
        /// </summary>
        /// <param name="panel">Панель, в которую будет добавлен DataGridView.</param>
        /// <param name="matrix">Матрица, которую нужно отобразить.</param>
        public static void ShowMatrix(Panel panel, in int[,] matrix)
        {
            // Создаем DataGridView и устанавливаем его свойства
            // Тут используется более современный DataGridView. Не тот же, что и в методичке.
            DataGridView dataGridView = new DataGridView();
            dataGridView.Dock = DockStyle.Fill;
            dataGridView.AllowUserToAddRows = false;
            dataGridView.AllowUserToDeleteRows = false;
            dataGridView.AllowUserToResizeColumns = false;
            dataGridView.AllowUserToResizeRows = false;
            dataGridView.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridView.CellValidating += dataGridView_CellValidating;

            // Создаем столбцы
            for (int i = 0; i < matrix.GetLength(1); i++)
            {
                dataGridView.Columns.Add("-", "-");
            }

            // Заполняем столбцы данными из матрицы
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                dataGridView.Rows.Add();
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    dataGridView.Rows[i].Cells[j].Value = matrix[i, j];
                }
            }
            // Добавляем DataGridView в Panel
            panel.Controls.Add(dataGridView);
            dataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.ColumnHeader;
        }
        private static void dataGridView_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            var dataGridView = sender as DataGridView;
            if (e.ColumnIndex >= 0 && e.RowIndex >= 0)
            {
                DataGridViewCell cell = dataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex];
                if (!int.TryParse(e.FormattedValue.ToString(), out int value))
                {
                    e.Cancel = true;
                    MessageBox.Show("Значение должно быть числом");
                }
            }
        }
        /// <summary>
        /// Обработчик события CellValidating для DataGridView.
        /// Проверяет, что в ячейке введено число.
        /// </summary>
        /// <param name="sender">Объект, вызвавший событие.</param>
        /// <param name="e">Аргументы события.</param>
        public static void RandomMatrix(ref int[,] matrix, int max_rand = 100)
        {
            Random random = new Random();
            for (int i = 0; i < matrix.GetLength(0); i++)
                for (int j = 0; j < matrix.GetLength(1); j++)
                    matrix[i, j] = random.Next(max_rand);
        }
        /// <summary>
        /// Умножает две матрицы.
        /// </summary>
        /// <param name="matrix1">Первая матрица.</param>
        /// <param name="matrix2">Вторая матрица.</param>
        /// <returns>Результат умножения двух матриц.</returns>
        public static int[,] MultiplyMatrices(int[,] matrix1, int[,] matrix2)
        {
            int rows1 = matrix1.GetLength(0);
            int rows2 = matrix2.GetLength(0);
            int columns1 = matrix1.GetLength(1);
            int columns2 = matrix2.GetLength(1);
            if (columns1 != rows2)
            {
                throw new ArgumentException($"Число столбцов первой матрицы ({columns1}) не равно числу строк второй({rows2}). " +
                    $"Умножение невозможно");
            }
            int[,] result = new int[rows1, columns2];

            for (int i = 0; i < rows1; i++)
                for (int j = 0; j < columns2; j++)
                    for (int k = 0; k < columns1; k++)
                    {
                        if (matrix1[i, k] <= 0 || matrix2[k, j] <= 0)
                        {
                            throw new ArgumentException("Недопустимые значения в ячейках матрицы. " +
                                "Значения в ячейках матрицы должны быть больше нуля!");
                        }

                        result[i, j] += matrix1[i, k] * matrix2[k, j];
                    }
            return result;
        }
        /// <summary>
        /// Получает матрицу из DataGridView в указанной панели.
        /// </summary>
        /// <param name="panel">Панель, содержащая DataGridView.</param>
        /// <param name="matrix">Матрица, полученная из DataGridView.</param>
        /// <returns>True, если удалось получить матрицу из DataGridView, иначе - false.</returns>
        public static bool try_get_matrix(Panel panel, out int[,] matrix)
        {
            if (panel.Controls.Count > 0)
            {
                var data_grid = (panel.Controls[panel.Controls.Count - 1] as DataGridView);
                matrix = new int[data_grid.Rows.Count, data_grid.Columns.Count];

                for (int i = 0; i < data_grid.Rows.Count; i++)
                {
                    for (int j = 0; j < data_grid.Columns.Count; j++)
                    {
                        DataGridViewCell cell = data_grid.Rows[i].Cells[j];
                        int value = Convert.ToInt32(cell.Value);
                        matrix[i, j] = value;
                    }
                }
                return true;
            }
            matrix = null;
            return false;
        }
    }

}
