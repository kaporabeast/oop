﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    internal class Task1
    {

        /// </summary>
        /// <param name="a">Первое целое число.</param>
        /// <param name="b">Второе целое число.</param>
        /// <returns>Наибольший общий делитель двух целых чисел.</returns>
        public static int FindGCDEuclid(int a, int b)
        {
            if (a == 0) { return b; } // Если a равно 0, то НОД равен b
            while (b != 0) // Пока b не равно 0
            {
                if (a > b) // Если a больше b
                {
                    a -= b; // Вычитаем b из a
                }
                else // Иначе
                {
                    b -= a; // Вычитаем a из b
                }
            }
            return a; // Возвращаем НОД
        }
    }
}
