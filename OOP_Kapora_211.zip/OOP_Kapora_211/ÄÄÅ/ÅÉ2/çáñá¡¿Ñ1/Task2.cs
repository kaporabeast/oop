﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание1
{
    internal class Task2
    {
        /// <summary>
        /// Вычисляет наибольший общий делитель двух целых чисел методом Евклида.
        /// </summary>
        /// <param name="a">Первое целое число.</param>
        /// <param name="b">Второе целое число.</param>
        /// <returns>Наибольший общий делитель двух целых чисел.</returns>
        private static int FindGCDEuclid(int a, int b)
        {
            if (a == 0) { return b; } // Если a равно 0, то НОД равен b
            while (b != 0) // Пока b не равно 0
            {
                if (a > b) // Если a больше b
                {
                    a -= b; // Вычитаем b из a
                }
                else // Иначе
                {
                    b -= a; // Вычитаем a из b
                }
            }
            return a; // Возвращаем НОД
        }
        /// <summary>
        /// Реализует метод Евклида для нахождения наибольшего общего делителя множества чисел.
        /// </summary>
        /// <param name="first">Первое число.</param>
        /// <param name="second">Второе число.</param>
        /// <param name="numbers">Последующие числа.</param>
        /// <returns>Наибольший общий делитель множества чисел.</returns>
        /// <remarks>
        /// При работе с большими числами может произойти переполнение. 
        /// Рекомендуется использовать тип данных, достаточный для хранения результатов вычислений,
        /// либо обрабатывать переполнение.
        /// </remarks>
        public static int FindGCDEuclid(params int[] numbers)
        {
            if (numbers.Length == 0) { return 0; } // Если массив пустой, то НОД равен 0
            if (numbers.Length == 1) { return numbers[0]; } // Если в массиве только одно число, то НОД равен этому числу
            int result = FindGCDEuclid(numbers[0], numbers[1]); // Находим НОД первых двух чисел

            for (int i = 2; i < numbers.Length; i++) // Проходим по оставшимся числам
            {
                result = FindGCDEuclid(result, numbers[i]); // Находим НОД текущего числа и предыдущего НОД
            }

            return result; // Возвращаем НОД
        }
        /// <summary>
        /// Вычисляет наибольший общий делитель нескольких целых чисел методом Евклида.
        /// </summary>
        /// <param name="str_numbers">Строковые представления целых чисел.</param>
        /// <returns>Наибольший общий делитель нескольких целых чисел.</returns>
        public static int FindGCDEuclid(params string[] str_numbers)
        {
            int[] numbers = new int[str_numbers.Length];

            for (int i = 0; i < str_numbers.Length; i++) // Проходим по строковым представлениям чисел
            {
                numbers[i] = int.Parse(str_numbers[i]); // Преобразуем строку в число
            }
            return FindGCDEuclid(numbers); // Вызываем метод для нахождения НОД
        }
    }
}