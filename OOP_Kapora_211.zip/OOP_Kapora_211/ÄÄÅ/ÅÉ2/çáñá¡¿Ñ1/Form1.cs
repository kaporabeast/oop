﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Linq.Expressions;
using System.Windows.Forms;
using System.Xml;
using Задание1;

namespace Task1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((textBox1.Text.Length == 0) || (textBox1.Text.Length == 0))
            {
                MessageBox.Show("Поля число1 и число2 не могут быть пустыми"); // Выводим сообщение об ошибке, если поля пустые
                return;
            }
            int num1, num2;
            if (!int.TryParse(textBox1.Text, out num1))
            {
                MessageBox.Show("Число в поле 1 слишком большое"); // Выводим сообщение об ошибке, если число в поле 1 слишком большое
            }
            if (!int.TryParse(textBox2.Text, out num2))
            {
                MessageBox.Show("Число в поле 2 слишком большое"); // Выводим сообщение об ошибке, если число в поле 2 слишком большое
            }
            int result = Task1.FindGCDEuclid(num1, num2); // Вычисляем НОД чисел и сохраняем результат в переменную result
            textBox3.Text = result.ToString(); // Выводим результат на форму
        }

        private void OnlyValidDecimal(in TextBox textbox, ref KeyPressEventArgs e)
        {
            char pressed = e.KeyChar;
            // 8 - это BackSlash
            //MessageBox.Show($"{textBox1.Text.Contains('1')}");
            if (!Char.IsDigit(pressed) && !((int)pressed == 8))
            {
                if ((pressed != '.') && (pressed != ','))
                {
                    e.Handled = true;
                }
                if (textbox.Text.Contains('.') || textbox.Text.Contains(',')) e.Handled = true;
            }
        }

        private void OnlyValidNumeric(ref KeyPressEventArgs e)
        {
            char pressed = e.KeyChar;
            // 8 - это BackSlash
            //MessageBox.Show($"{textBox1.Text.Contains('1')}");
            if (!Char.IsDigit(pressed) && !((int)pressed == 8))
            {
                e.Handled = true;
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            OnlyValidNumeric(ref e); // Проверяем, что введенные символы являются цифрами
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            OnlyValidNumeric(ref e); // Проверяем, что введенные символы являются цифрами
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            OnlyValidNumeric(ref e); // Проверяем, что введенные символы являются цифрами
            if (e.KeyChar == ',' || e.KeyChar == ' ')
            {
                e.Handled = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string[] input = textBox4.Text.Replace(" ", "").Split(','); // Разбиваем строку на массив строк, используя запятую в качестве разделителя
            try
            {
                textBox5.Text = Task2.FindGCDEuclid(input).ToString(); // Вычисляем НОД чисел и выводим результат на форму
            }
            catch (System.FormatException)
            {
                MessageBox.Show("Входная строка имела неправильный формат"); // Выводим сообщение об ошибке, если входная строка имела неправильный формат
            }
            catch (System.OverflowException)
            {
                MessageBox.Show("Числа слишком большие!"); // Выводим сообщение об ошибке, если числа слишком большие
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Stopwatch stopwatch1 = new Stopwatch(); // Создаем объект Stopwatch для измерения времени выполнения алгоритма Евклида
            Stopwatch stopwatch2 = new Stopwatch(); // Создаем объект Stopwatch для измерения времени выполнения алгоритма Стейна
            string[] input = textBox6.Text.Replace(" ", "").Split(','); // Разбиваем строку на массив строк, используя запятую в качестве разделителя
            try
            {
                stopwatch1.Start(); // Запускаем измерение времени выполнения алгоритма Евклида
                textBox7.Text = Task3.FindGCDEuclid(input).ToString(); // Вычисляем НОД чисел с помощью алгоритма Евклида и выводим результат на форму
                stopwatch1.Stop(); // Останавливаем измерение времени выполнения алгоритма Евклида
                stopwatch2.Start(); // Запускаем измерение времени выполнения алгоритма Стейна
                textBox8.Text = Task3.FindGCDStein(input).ToString(); // Вычисляем НОД чисел с помощью алгоритма Стейна и выводим результат на форму
                stopwatch2.Stop(); // Останавливаем измерение времени выполнения алгоритма Стейна
            }
            catch (System.FormatException)
            {
                MessageBox.Show("Входная строка имела неправильный формат"); // Выводим сообщение об ошибке, если входная строка имела неправильный формат
                return;
            }
            catch (System.OverflowException)
            {
                MessageBox.Show("Числа слишком большие!"); // Выводим сообщение об ошибке, если числа слишком большие
                return;
            }
            long elapsedNanoSeconds1 = stopwatch1.ElapsedTicks; // Получаем количество тиков, затраченных на выполнение алгоритма Евклида
            long elapsedNanoSeconds2 = stopwatch2.ElapsedTicks; // Получаем количество тиков, затраченных на выполнение алгоритма Стейна
            textBox9.Text = elapsedNanoSeconds1.ToString(); // Выводим количество тиков, затраченных на выполнение алгоритма Евклида, на форму
            textBox10.Text = elapsedNanoSeconds2.ToString(); // Выводим количество тиков, затраченных на выполнение алгоритма Стейна, на форму
            textBox11.Text = Math.Abs(elapsedNanoSeconds1 - elapsedNanoSeconds2).ToString(); // Выводим разницу во времени выполнения алгоритмов на форму
        }

        private void textBox_OnlyValid_Numeric_KeyPress(object sender, KeyPressEventArgs e)
        {
            OnlyValidNumeric(ref e); // Проверяем, что введенные символы являются цифрами
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (panel1.Controls.Count > 0)
            {
                panel1.Controls.RemoveAt(panel1.Controls.Count - 1); // Удаляем предыдущую матрицу, если она была нарисована
            }
            // Создаем матрицу
            int columns, rows;
            try
            {
                (columns, rows) = (int.Parse(textBox12.Text), int.Parse(textBox13.Text)); // Получаем количество столбцов и строк матрицы из текстовых полей
            }
            catch (FormatException)
            {
                MessageBox.Show("Значения столбцов или строк имеют неверный формат!"); // Выводим сообщение об ошибке, если значения столбцов или строк имеют неверный формат
                return;
            }
            int[,] matrix1 = new int[rows, columns]; // Создаем матрицу
            Array.Clear(matrix1, 0, matrix1.Length); // Заполняем матрицу нулями
            try
            {
                Task4.ShowMatrix(panel1, in matrix1); // Рисуем матрицу на панели
            }
            catch (System.InvalidOperationException)
            {
                MessageBox.Show("Слишком большая матрица"); // Выводим сообщение об ошибке, если матрица слишком большая
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (panel2.Controls.Count > 0)
            {
                panel2.Controls.RemoveAt(panel2.Controls.Count - 1); // Удаляем предыдущую матрицу, если она была нарисована
            }
            // Создаем матрицу
            int columns, rows;
            try
            {
                (columns, rows) = (int.Parse(textBox15.Text), int.Parse(textBox14.Text)); // Получаем количество столбцов и строк матрицы из текстовых полей
            }
            catch (FormatException)
            {
                MessageBox.Show("Значения столбцов или строк имеют неверный формат!"); // Выводим сообщение об ошибке, если значения столбцов или строк имеют неверный формат
                return;
            }
            int[,] matrix2 = new int[rows, columns]; // Создаем матрицу
            Array.Clear(matrix2, 0, matrix2.Length); // Заполняем матрицу нулями
            try
            {
                Task4.ShowMatrix(panel2, in matrix2); // Рисуем матрицу на панели
            }
            catch (System.InvalidOperationException)
            {
                MessageBox.Show("Слишком большая матрица"); // Выводим сообщение об ошибке, если матрица слишком большая
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int[,] matrix1, matrix2;
            if (!Task4.try_get_matrix(panel1, out matrix1) || !Task4.try_get_matrix(panel2, out matrix2))
            {
                MessageBox.Show("Сначала нужно создать матрицы"); // Выводим сообщение об ошибке, если матрицы еще не созданы
                return;
            }
            var (rows1, columns1) = (matrix1.GetLength(0), matrix1.GetLength(1));
            var (rows2, columns2) = (matrix2.GetLength(0), matrix2.GetLength(1));
            if (columns1 != rows2)
            {
                MessageBox.Show("Умножение матриц возможно только в том случае, " +
                    "\nесли число столбцов первой матрицы равно числу строк второй матрицы!"); // Выводим сообщение об ошибке, если матрицы нельзя перемножить
                return;
            }
            int[,] matrix3 = Task4.MultiplyMatrices(matrix1, matrix2); // Умножаем матрицы и сохраняем результат в переменную matrix3
            if (panel3.Controls.Count > 0)
            {
                panel3.Controls.RemoveAt(panel3.Controls.Count - 1); // Удаляем предыдущую матрицу, если она была нарисована
            }
            Task4.ShowMatrix(panel3, in matrix3); // Рисуем матрицу на панели
        }

        private void button7_Click(object sender, EventArgs e)
        {
            int[,] matrix1, matrix2;
            if (Task4.try_get_matrix(panel1, out matrix1))
            {
                Task4.RandomMatrix(ref matrix1); // Заполняем матрицу случайными числами
                panel1.Controls.RemoveAt(panel1.Controls.Count - 1); // Удаляем предыдущую матрицу, если она была нарисована
                Task4.ShowMatrix(panel1, matrix1); // Рисуем матрицу на панели
            }
            if (Task4.try_get_matrix(panel2, out matrix2))
            {
                Task4.RandomMatrix(ref matrix2); // Заполняем матрицу случайными числами
                panel2.Controls.RemoveAt(panel2.Controls.Count - 1); // Удаляем предыдущую матрицу, если она была нарисована
                Task4.ShowMatrix(panel2, matrix2); // Рисуем матрицу на панели
            }
        }
    }
}