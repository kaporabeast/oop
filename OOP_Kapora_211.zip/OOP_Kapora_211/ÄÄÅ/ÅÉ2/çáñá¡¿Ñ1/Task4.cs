﻿using System;
using System.Collections.Generic;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Задание1
{
    internal class Task4
    {
        /// <summary>
        /// Отображает матрицу в DataGridView в указанной панели.
        /// </summary>
        /// <param name="panel">Панель, в которую будет добавлен DataGridView.</param>
        /// <param name="matrix">Матрица, которую нужно отобразить.</param>
        public static void ShowMatrix(Panel panel, in int[,] matrix)
        {
            // Создаем новый объект DataGridView
            DataGridView dataGridView = new DataGridView();
            // Устанавливаем свойство Dock для заполнения всей панели
            dataGridView.Dock = DockStyle.Fill;
            // Запрещаем пользователю добавлять и удалять строки и изменять размеры столбцов и строк
            dataGridView.AllowUserToAddRows = false;
            dataGridView.AllowUserToDeleteRows = false;
            dataGridView.AllowUserToResizeColumns = false;
            dataGridView.AllowUserToResizeRows = false;
            // Отключаем изменение размера заголовков строк
            dataGridView.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            // Добавляем обработчик события CellValidating для проверки вводимых данных
            dataGridView.CellValidating += dataGridView_CellValidating;

            // Создаем столбцы в DataGridView
            for (int i = 0; i < matrix.GetLength(1); i++)
            {
                dataGridView.Columns.Add("-", "-");
            }

            // Заполняем столбцы данными из матрицы
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                dataGridView.Rows.Add();
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    dataGridView.Rows[i].Cells[j].Value = matrix[i, j];
                }
            }
            // Добавляем DataGridView на панель
            panel.Controls.Add(dataGridView);
            // Устанавливаем автоматическое изменение размеров столбцов и строк
            dataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.ColumnHeader;
        }
        // Обработчик события CellValidating для проверки вводимых данных в ячейки DataGridView
        private static void dataGridView_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            // Приводим объект-отправитель к типу DataGridView
            var dataGridView = sender as DataGridView;
            // Проверяем, что индексы столбца и строки ячейки не отрицательные
            if (e.ColumnIndex >= 0 && e.RowIndex >= 0)
            {
                // Получаем ячейку DataGridView по индексам столбца и строки
                DataGridViewCell cell = dataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex];
                // Проверяем, что введенное значение можно преобразовать в целое число
                if (!int.TryParse(e.FormattedValue.ToString(), out int value))
                {
                    // Если значение нельзя преобразовать, отменяем изменение ячейки и выводим сообщение об ошибке
                    e.Cancel = true;
                    MessageBox.Show("Значение должно быть числом");
                }
            }
        }
        /// <summary>
        /// Обработчик события CellValidating для DataGridView.
        /// Проверяет, что в ячейке введено число.
        /// </summary>
        /// <param name="sender">Объект, вызвавший событие.</param>
        /// <param name="e">Аргументы события.</param>
        public static void RandomMatrix(ref int[,] matrix, int max_rand = 100)
        {
            // Создаем объект класса Random для генерации случайных чисел
            Random random = new Random();
            // Заполняем матрицу случайными числами
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    matrix[i, j] = random.Next(max_rand);
                }
            }
        }
        /// <summary>
        /// Умножает две матрицы.
        /// </summary>
        /// <param name="matrix1">Первая матрица.</param>
        /// <param name="matrix2">Вторая матрица.</param>
        /// <returns>Результат умножения двух матриц.</returns>
        // Метод для умножения двух матриц
        public static int[,] MultiplyMatrices(int[,] matrix1, int[,] matrix2)
        {
            // Получаем количество строк и столбцов первой матрицы
            int rows1 = matrix1.GetLength(0);
            int columns1 = matrix1.GetLength(1);
            // Получаем количество столбцов второй матрицы
            int columns2 = matrix2.GetLength(1);
            // Создаем новую матрицу для хранения результата умножения
            int[,] result = new int[rows1, columns2];

            // Выполняем умножение матриц
            for (int i = 0; i < rows1; i++)
            {
                for (int j = 0; j < columns2; j++)
                {
                    for (int k = 0; k < columns1; k++)
                    {
                        result[i, j] += matrix1[i, k] * matrix2[k, j];
                    }
                }
            }

            // Возвращаем результат умножения
            return result;
        }
        /// <summary>
        /// Получает матрицу из DataGridView в указанной панели.
        /// </summary>
        /// <param name="panel">Панель, содержащая DataGridView.</param>
        /// <param name="matrix">Матрица, полученная из DataGridView.</param>
        /// <returns>True, если удалось получить матрицу из DataGridView, иначе - false.</returns>
        // Метод для получения матрицы из DataGridView на панели
        public static bool try_get_matrix(Panel panel, out int[,] matrix)
        {
            // Проверяем, что на панели есть хотя бы один элемент управления
            if (panel.Controls.Count > 0)
            {
                // Получаем DataGridView из последнего элемента управления на панели
                var data_grid = (panel.Controls[panel.Controls.Count - 1] as DataGridView);
                // Создаем новую матрицу с размерами DataGridView
                matrix = new int[data_grid.Rows.Count, data_grid.Columns.Count];

                // Заполняем матрицу значениями из DataGridView
                for (int i = 0; i < data_grid.Rows.Count; i++)
                {
                    for (int j = 0; j < data_grid.Columns.Count; j++)
                    {
                        DataGridViewCell cell = data_grid.Rows[i].Cells[j];
                        int value = Convert.ToInt32(cell.Value);
                        matrix[i, j] = value;
                    }
                }
                // Возвращаем true, если матрица успешно получена
                return true;
            }
            // Если на панели нет элементов управления, возвращаем false и пустую матрицу
            matrix = null;
            return false;
        }
    }
}
